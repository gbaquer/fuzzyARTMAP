library(shiny)
library(fuzzyARTMAP)

#Modules
#Reference: http://shiny.rstudio.com/articles/modules.html

#Namespace function generator
NS <- function(parent_id){function(child_id){paste(parent_id,child_id, sep="_")}}

#'button' Module (UI)
buttonUI <- function(id,text="Click here",iconName=NULL) {
  ns <- NS(id)
  tagList(
    actionButton(ns('button'), text,icon=icon(iconName)),
    uiOutput(ns('info')))
}
    
# 'dataPoolViewer' Module (UI)
dataPoolViewerUI <- function(id) {
    ns <- NS(id)
    
    tagList(
      h4('Data pool'),
      tableOutput(ns('table'))
    )
  }

# 'dataPoolViewer' Module (UI)
netPoolViewerUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    h4('Network pool'),
    tableOutput(ns('table'))
  )
}

# 'wksp' Module (UI)
wkspUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    h3('Workspace'),
    column(
      width=6,
      tagList(
        h4('Export Workspace'),              
        downloadButton(ns('wkspExport'), 'Export Workspace'))),
    column(
      width=6,
      tagList(
        h4('Import Workspace'),
        fileInput(ns('wkspImport'), NULL, accept = '.rds'))),
    netPoolViewerUI(ns('netPoolViewer')),
    dataPoolViewerUI(ns('dataPoolViewer'))
  )
} 

# 'uploadcsv' Module (UI)
uploadcsvUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    h4('Upload dataset file'),
    fileInput(ns('file'), NULL,
              accept = c(
                'text/csv',
                'text/comma-separated-values',
                'text/tab-separated-values',
                'text/plain',
                '.csv',
                '.tsv'
              )
    ),
    textInput(ns("dataSetName"), "Name"),
    selectInput(ns('dataSetType'), 'Type',c(Training='Training',Operation='Operation')),
    buttonUI(ns("addToPool"),text="Add workspace",iconName='upload'),
    h4('Input file configuration'),
    checkboxInput(ns('header'), 'Header', TRUE),
    selectInput(ns('sep'), 'Separator', c(Semicolon=';',Comma=',',Tab='\t')),
    selectInput(ns('dec'), 'Decimal', c('Comma'=',','Dot'="."))
  )
}

# 'datasetPreview' Module (UI)
# CHANGE#
uploadcsvPreviewUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    h4('View data'),
    selectInput(ns('datasetSelect'), NULL,'-'),
    tableOutput(ns('details')),
    downloadButton(ns('export'), 'Export .csv'),
    buttonUI(ns("delete"),text="Delete",iconName='remove'),    
    tableOutput(id)
  )
}

# 'modifyNet' Module (UI)
modifyNetUI <- function(id) {
  ns <- NS(id)
  
  tagList(    
    h4('Create/Modify network'),
    selectInput(ns('netSelect'), NULL,'[+] New network'),
    
    splitLayout(
      tagList(
        textInput(ns("name"), "Name"),
        numericInput(ns("numFeatures"), "Num Features",value=1,min=1,step=1),
        numericInput(ns("numClasses"), "Num Classes",value=2,min=2,step=1)),        
      tagList(
        numericInput(ns("maxNumCategories"), "Max Num Categories",value=1000,min=1,step=1),
        numericInput(ns("vigilance"), "Vigilance",value=0.75,min=0,max=1,step=0.01),
        numericInput(ns("bias"), "Bias",value=0.000001,min=0,step=0.0000001)),
      tagList(    
        numericInput(ns("numEpochs"), "Num Epochs",value=100,min=1,step=1),
        numericInput(ns("learningRate"), "Learning Rate",value=1,min=0,max=1,step=0.01))),
    uiOutput(ns('panel'))   
    
  )
}

# 'uploadNetwork' Module (UI)
#CHANGE#
uploadrdsUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    fileInput(ns('file'), NULL,accept = c('.rds')),
    splitLayout(
      textInput(ns('name'),NULL,value='New Net'),
      buttonUI(ns('addToPool'),'Add to workspace',iconName='upload'))
  )
}

# 'operationTraining' Module (UI)
#CHANGE#
netdataSelectUI <- function(id) {
  ns <- NS(id)
  
  tagList(
    h4("Select network and datasets"),
    tagList(
      column(
        width=6,
        selectInput(ns('netSelect'), "Network",'-')),
      column(
        width=6,
        selectInput(ns('datasetSelect'), "Dataset",'-'))),
    uiOutput(ns('trainingRatio')),
    buttonUI(ns('run'),"Run",iconName='play')
  )
}



