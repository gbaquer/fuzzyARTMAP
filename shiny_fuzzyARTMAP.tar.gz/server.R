shinyServer(function(input, output, session) {
  # Workspace Object
  wkspObject <- reactiveValues(netPool=list(), dataPool=list(),tmp=list())
  
  # Add a new dataset to the workspace
  add_to_dataPool <- function(name="dataset",type="Training",inputData=NULL,outputData=NULL){
    id=length(wkspObject$dataPool)+1;
    if(!is.null(wkspObject$dataPool[[name]]))
    {
      stop("This name is already in use")
      return()
    }
    newDatasetObject = list("id"= id, "name" = name, "type" = type, 
                            "inputData"=inputData, "outputData"=outputData,
                            "numFeatures"=ncol(inputData)*2,"numSamples"=nrow(inputData));
    
    wkspObject$dataPool[[name]] <<- newDatasetObject;
    print(paste("The new dataset",name,"was succesfully added to the workspace"));
  }
  
  # Add a new network to the workspace
  add_to_netPool <- function(name="net",net=NULL,history=NULL){
    id=length(wkspObject$netPool)+1;
    if(!is.null(wkspObject$netPool[[name]]))
    {
      stop("This name is already in use")
      return()
    }
    if(is.null(history))
    {
      history=list("Creation"=list("dataset"="-creation-","type"="-creation-","date"=Sys.Date(),"time"=Sys.time()))
    }
    newNetObject = list("id"= id, "name" = name, "net"=net,"history"=history);
    
    wkspObject$netPool[[name]] <<- newNetObject;
    print(paste("The new network",name,"was succesfully added to the workspace"));
  }
  
  # Bind input and output data in 1 matrix
  reconstructData <- function(inputData,outputData)
  {
    if(is.null(outputData))
      inputData
    else
      cbind(inputData,outputData)
  }
  
  # Helper function constructor used in filtering
  byField <- function(field,val){function(x,a=val,b=field){x[[b]]==a}}
  
  # 'button' Module (server)
  button <- function(input, output, session, id, handler=function(){}) {
    ns <- NS(id)
    outputTags <- reactive({
      if(input[[ns('button')]][1]==0)
        return ("")
      isolate({
        handler()
      })
    })
    output[[ns('info')]] <- renderUI ({
      outputTags()
    })
  }
  
  # 'dataPoolViewer' Module (server)
  dataPoolViewer <- function(input, output, session, id) {
    ns <- NS(id)
    output[[ns('table')]] <- renderTable({
      pool=wkspObject$dataPool
      data.frame(
        list("Name"=matrix(lapply(pool,function(x){c(x[['name']])})),
              "Type"=matrix(lapply(pool,function(x){c(x[['type']])})),
              "Features"=matrix(lapply(pool,function(x){c(x[['numFeatures']])})),
              "Samples"=matrix(lapply(pool,function(x){c(x[['numSamples']])}))
             )
        )
    })    
  }
  
  # 'netPoolViewer' Module (server)
  netPoolViewer <- function(input, output, session, id) {
    ns <- NS(id)
    output[[ns('table')]] <- renderTable({
      pool=wkspObject$netPool
      data.frame(
        list("Name"=matrix(lapply(pool,function(x){c(x[['name']])})),
             "Features"=matrix(lapply(pool,function(x){c(x$net[['numFeatures']])})),
             "Categories"=matrix(lapply(pool,function(x){c(x$net[['numCategories']])})),
             "Vigilance"=matrix(lapply(pool,function(x){c(x$net[['vigilance']])})),
             "L.R."=matrix(lapply(pool,function(x){c(x$net[['learningRate']])}))
        )
      )
    })    
  }
  
  # 'wksp' Module (server)
  wksp <- function(input, output, session, id) {
    ns <- NS(id)
    netPoolViewer(input, output, session, ns('netPoolViewer')) 
    dataPoolViewer(input, output, session, ns('dataPoolViewer')) 
    
    output[[ns('wkspExport')]] <- downloadHandler(
      filename = function() {paste('workspace_', Sys.Date(), '.rds',sep='')},
      content = function(con) {saveRDS(list("netPool"=wkspObject$netPool,"dataPool"=wkspObject$dataPool), file = con)}
    )  
    
    observe({
      inFile <- input[[ns('wkspImport')]]
      
      if (is.null(inFile)) return(NULL)
      
      isolate({
        tmp=readRDS(inFile$datapath)
        wkspObject$dataPool=tmp$dataPool
        wkspObject$netPool=tmp$netPool
      })
    })
  }
  
  # 'dataManager' Module (server)
  #CHANGE#
  uploadcsv <- function(input, output, session, id) {
    ns <- NS(id)
    nsprev <- function(x){paste(ns('preview'),x,sep='_')}
    
    
    selectedDataSet <- reactive({
      if(input[[nsprev('datasetSelect')]]=='-')
      {
        return (NULL)
      }
      isolate({
        dataset=wkspObject$dataPool[[input[[nsprev('datasetSelect')]]]] 
      })
    })
    
    excelData <- reactive({
      inFile <- input[[ns('file')]]
      
      if (is.null(inFile))
        return(NULL)
      
      read.csv(inFile$datapath, header = input[[ns('header')]],
               sep = input[[ns('sep')]], quote = "'", dec=input[[ns('dec')]],row.names=1)
    })
    
    output[[ns('preview')]] <- renderTable({
      dataset=selectedDataSet()
      if(is.null(dataset))
        excelData()
      else
        reconstructData(dataset[["inputData"]],dataset[["outputData"]])
    }) 
    
    output[[nsprev('details')]] <- renderTable({
      dataset=selectedDataSet()
      if(is.null(dataset))
        matrix(c('Name:','-','Type:','-','Number of Features:','-','Number of Entries:','-'),2,4)
      else
        matrix(c('Name:',dataset['name'],'Type:',dataset['type'],
                 'Number of Features:',dataset['numFeatures'],'Number of Samples:',dataset['numSamples']),2,4)
    },include.rownames=FALSE, include.colnames=FALSE
    ) 
    
    observe({
      pool=wkspObject$dataPool
      updateSelectInput(session, nsprev('datasetSelect'),choices = c('-',ls(pool)))
      updateTextInput(session, ns("dataSetName"),value = paste("Dataset",length(pool)+1))
    })
    
    output[[nsprev('export')]] <- downloadHandler(
      filename = function() {
        paste(selectedDataSet()[['name']], Sys.Date(), '.csv',sep='')
      },
      content = function(con) {
        write.table(reconstructData(selectedDataSet()[['inputData']],selectedDataSet()[['outputData']]), 
                    file =con, sep = input[[ns('sep')]], dec=input[[ns('dec')]],na='-',col.names = NA)
      }
    )  
    
    button(input, output, session, nsprev("delete"), function(){
      #Ask for confirmation
      print(paste('You are about to delete',selectedDataSet()[['name']]))
      wkspObject$dataPool[[selectedDataSet()[['name']]]]=NULL
         
    })
      
    button(input, output, session, ns("addToPool"), function(){
      if(input[[ns('dataSetType')]]=='Operation')
      {
        inputData = excelData()
        outputData = NULL
      }
      else
      {
        last = length(excelData())
        outputData = excelData()[c(last:last)]
        inputData = excelData()[c(1:(last-1))]
      }
      add_to_dataPool(name=input[[ns("dataSetName")]],type=input[[ns('dataSetType')]],inputData,outputData)    
    })
  }
  
  # 'modifyNet' Module (server)
  modifyNet <- function(input, output, session, id) {
    ns <- NS(id)
    
    selectedNet <- reactive({
      if(is.null(input[[ns('netSelect')]])||input[[ns('netSelect')]]=='[+] New network')
      {
        return (NULL)
      }
      isolate({
        net=wkspObject$netPool[[input[[ns('netSelect')]]]] 
      })
    })
    
    panel <- reactive({   
      if(is.null(selectedNet()))
      {
        tagList(buttonUI(ns("addToPool"),text="Add to workspace",iconName='upload'))
      }
      else
      {
        tagList(       
              downloadButton(ns('export'), 'Export .rds'),
              tags$a(buttonUI(ns("update"),text="Update",iconName='refresh'),class="btn"),
              tags$a(buttonUI(ns("copy"),text="Make a copy",iconName='copy'),class="btn"),
              tags$a(buttonUI(ns("delete"),text="Delete",iconName='remove'),class="btn"))
              
      }
    })
    
    observe({
      pool=wkspObject$netPool      
      updateSelectInput(session, ns('netSelect'),choices = c('[+] New network',ls(pool)))
    })
    
    observe({      
      netObject=selectedNet()
          
      if(is.null(netObject))
      {
        values=list("name"=paste("Net",(length(wkspObject$netPool)+1)),"numFeatures"=0,"numClasses"=0,
                    "maxNumCategories"=1000,"vigilance"=0.75,"bias"=0.000001,"numEpochs"=100,"learningRate"=1)
      }
      else
      {
        net=netObject$net
        values=list("name"=netObject$name,"numFeatures"=net$numFeatures,"numClasses"=net$numClasses,
             "maxNumCategories"=net$maxNumCategories,"vigilance"=net$vigilance,
             "bias"=net$bias,"numEpochs"=net$numEpochs,"learningRate"=net$learningRate)
        #Add buttons, weights and extra info
      }      
      updateTextInput(session, ns("name"),value = values$name)
      updateNumericInput(session,ns("numFeatures"),value=values$numFeatures)
      updateNumericInput(session,ns("numClasses"),value=values$numClasses)
      updateNumericInput(session,ns("maxNumCategories"),value=values$maxNumCategories)
      updateNumericInput(session,ns("vigilance"),value=values$vigilance)
      updateNumericInput(session,ns("bias"),value=values$bias)
      updateNumericInput(session,ns("numEpochs"),value=values$numEpochs)
      updateNumericInput(session,ns("learningRate"),value=values$learningRate)      
    })
    
    output[[ns('panel')]] <- renderUI(panel())
    
    output[[ns('export')]] <- downloadHandler(
      filename = function() {paste(selectedNet()[['name']],'.rds',sep='')},
      content = function(con) {saveRDS(wkspObject$netPool[[selectedNet()[['name']]]], file = con)}
    )  
    
    button(input, output, session, ns("delete"), function(){
      print(paste('You are about to delete',selectedNet()[['name']]))
      wkspObject$netPool[[selectedNet()[['name']]]]=NULL
    })
    
    button(input, output, session, ns("update"), function(){
      netObject=selectedNet()
      
      newName=input[[ns("name")]]
      oldName = input[[ns('netSelect')]]
      
      netObject[["name"]]=newName
      netObject$net[["maxNumCategories"]]=input[[ns("maxNumCategories")]]
      netObject$net[["vigilance"]]=input[[ns("vigilance")]]
      netObject$net[["bias"]]=input[[ns("bias")]]
      netObject$net[["numEpochs"]]=input[[ns("numEpochs")]]
      netObject$net[["learningRate"]]=input[[ns("learningRate")]]
      
      wkspObject$netPool[[oldName]]=NULL
      wkspObject$netPool[[newName]]=netObject
      
      return(tagList())
    })
    
    button(input, output, session, ns("copy"), function(){
      netObject=selectedNet()      
      newName=paste(netObject[["name"]],'(copy)')
      netObject$name=newName
      wkspObject$netPool[[newName]]=netObject
      return(tagList())
    })
  
    button(input, output, session, ns("addToPool"), function(){
      add_to_netPool(name=input[[ns("name")]],net=ARTMAP_Create_Network(
          numFeatures=input[[ns("numFeatures")]], numClasses=input[[ns("numClasses")]],
          maxNumCategories=input[[ns("maxNumCategories")]], vigilance=input[[ns("vigilance")]], 
          bias=input[[ns("bias")]], numEpochs=input[[ns("numEpochs")]], learningRate=input[[ns("learningRate")]]
        ))
      })
  }
  
  # 'uploadNetwork' Module (server)
  #CHANGE#
  uploadrds <- function(input, output, session, id) {
    ns <- NS(id)
    netObject<-reactive({
      inFile <- input[[ns('file')]]
      
      if (is.null(inFile)) return(NULL)
      
      isolate({
        netObject=readRDS(inFile$datapath)
      })
    })
    observe({
      netObject=netObject()
      updateTextInput(session, ns("name"),value = netObject$name)
    })
    button(input, output, session, ns("addToPool"), function(){
      netObject=netObject()
      add_to_netPool(name=input[[ns("name")]],net=netObject$net,history=netObject$history)
    })
  }
  
  # 'operationTraining' Module (server)
  netdataSelect <- function(input, output, session, id, type) {
    ns <- NS(id)
    
    filteredDatasets <- reactive({
      if(is.null(input[[ns('netSelect')]])||input[[ns('netSelect')]]=='-') 
        return(NULL)
      pool=wkspObject$dataPool
      selectedNet = wkspObject$netPool[[input[[ns('netSelect')]]]]$net
      ls(Filter(byField("numFeatures",selectedNet[['numFeatures']]),
                Filter(byField("type",type),pool)))
    })
    observe({
      pool=wkspObject$netPool
      updateSelectInput(session, ns('netSelect'),choices = c('-',ls(pool)))
    })
    observe({
      updateSelectInput(session, ns('datasetSelect'),choices = c('-',filteredDatasets()))
    })
    output[[ns('trainingRatio')]] <- renderUI({
      if(type=="Operation")
        tagList()
      if(type=="Training")
        tagList(sliderInput(ns('trainingRatioSlider'),"Training/Validation ratio",0,100,80,1))
    })
    
    button(input, output, session, ns("addTrainedNet"), function(){
      add_to_netPool(name=input[[ns('newName')]],net=wkspObject$tmp[["lastTrainedNet"]]$net)
    })
    button(input, output, session, ns('addResultData'), function(){
      add_to_dataPool(name=input[[ns('newName')]],type='Result',
                      inputData=wkspObject$tmp[["lastResultData"]]$inputData,
                      outputData=wkspObject$tmp[["lastResultData"]]$outputData)
    })
    
    button(input, output, session, ns("run"), function(){
      #Get Input and Supervisor Data from loaded excel file
      netObject=wkspObject$netPool[[input[[ns('netSelect')]]]]
      net=netObject$net
      dataObject=wkspObject$dataPool[[input[[ns('datasetSelect')]]]]
      inputData=dataObject$inputData
      if(type=='Training')
      {
        supData=dataObject$outputData
        
        trainingRatio = input[[ns('trainingRatioSlider')]];
        max=nrow(inputData);
        mid=floor(max/100*trainingRatio);
        
        trainingInput = inputData[1:mid,];
        validationInput = inputData[mid:max,];
        trainingSup = matrix(supData[1:mid,],mid,1);
        validationSup = supData[mid:max,];
        
        if(trainingRatio!=0)
        {
          ccTrainingInput = ART_Complement_Code(trainingInput);
          newNet = ARTMAP_Learn(net, ccTrainingInput, trainingSup);
          
          wkspObject$tmp[["lastTrainedNet"]]=list(name=netObject$name,net=newNet)
          
          trainingResults =  tagList(
                              h5('Training'),
                              wellPanel(
                                p(paste('Training samples:',mid)),
                                p(paste('Epochs needed:',newNet$neededEpochs)),
                                p(paste('Number of categories:',newNet$numCategories)),
                                textInput(ns('newName'),NULL,paste(netObject$name,'(copy)')),
                                buttonUI(ns('addTrainedNet'),'Add to workspace',iconName='upload')));
        }
        else{
          newNet=net;
          trainingResults = NULL;
        }
        if(trainingRatio!=100)
        {
          ccValidationInput = ART_Complement_Code(validationInput);
          class = ARTMAP_Classify(newNet, ccValidationInput);
          accuracy=round(sum(class==validationSup)/(max-mid+1)*100,2);
          print(class);
          print(accuracy);
          validationResults = tagList(
                                h5('Validation'),
                                wellPanel(
                                  p(paste('Validation samples:',max-mid)),
                                  p(paste('Accuracy:',accuracy,'%'))));
        }
        else{
          validationResults = NULL;
        }
        return(tagList(
                tags$hr(),
                h4('Results'),
                splitLayout(trainingResults,validationResults)))
      }
      if(type=='Operation')
      {
        ccInput = ART_Complement_Code(inputData);
        outputData = ARTMAP_Classify(net, ccInput);
        colnames(outputData)=c('Output');
        wkspObject$tmp[["lastResultData"]]=list(netName=netObject$name,dataName=dataObject$name,
                                     inputData=inputData,outputData=outputData)
        return (tagList(
          tags$hr(),
          h4('Save operation results'),
          textInput(ns('newName'),'New data set name',paste(dataObject$name,'(result)')),
          buttonUI(ns('addResultData'),'Add to workspace',iconName='upload')
          ))
      }
      
    })
  }
    
  wksp1 <- wksp(input,output,session,id='wksp1')
  wksp2 <- wksp(input,output,session,id='wksp2')
  
  uploadcsv1 <- uploadcsv(input,output,session,id="uploadcsv1")
  uploadcsv2 <- uploadcsv(input,output,session,id="uploadcsv2")
  
  uploadrds1 <- uploadrds(input,output,session,id="uploadrds1")
  
  dataPoolViewer1 <- dataPoolViewer(input, output, session, 'dataPoolViewer1')
  dataPoolViewer2 <- dataPoolViewer(input, output, session, 'dataPoolViewer2')
  
  netPoolViewer1 <- netPoolViewer(input, output, session, 'netPoolViewer1')
  netPoolViewer2 <- netPoolViewer(input, output, session, 'netPoolViewer2')
  
  modifyNet1 <- modifyNet(input, output, session, 'modifyNet1')
  modifyNet2 <- modifyNet(input, output, session, 'modifyNet2')
  
  netdataSelect1 <- netdataSelect(input, output, session, 'netdataSelect1', 'Operation')
  netdataSelect2 <- netdataSelect(input, output, session, 'netdataSelect2', 'Training')
})
