shinyUI(
  navbarPage("Fuzzy Artmap Neural Networks",
                    tabPanel("Network Operation",
                            sidebarLayout(
                              sidebarPanel(
                                wkspUI("wksp1")                                
                              ),                              
                              mainPanel(
                                netdataSelectUI("netdataSelect1")
                              )
                            )
                   ),
                   tabPanel("Network Training/Validation",
                            sidebarLayout(
                              sidebarPanel(
                                wkspUI("wksp2")                                 
                              ),                               
                              mainPanel(
                                netdataSelectUI("netdataSelect2")
                              )
                            )
                   ),
                   tabPanel("Network Manager",
                            sidebarLayout(
                              sidebarPanel(
                                h4('Upload network file'),
                                uploadrdsUI('uploadrds1'),
                                netPoolViewerUI('netPoolViewer1')
                              ),                               
                              mainPanel(
                                modifyNetUI('modifyNet1')
                              )
                            )
                   ),
                    tabPanel("Data Manager",
                             sidebarLayout(
                               sidebarPanel(
                                 uploadcsvUI('uploadcsv2'),
                                 width=3
                               ),                               
                               mainPanel(
                                 column(
                                   width=8,
                                   uploadcsvPreviewUI('uploadcsv2_preview')),
                                 column(
                                   width=4,
                                   dataPoolViewerUI('dataPoolViewer1')),
                                 width=9                               
                               )
                              )
                             ),                   
                   header = NULL,
                   theme=NULL,
                   collapsible = TRUE    
                   
))

